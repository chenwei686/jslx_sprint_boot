CREATE FUNCTION DistanceMath(outerLongitude DOUBLE, outerLatitude DOUBLE, innerLongitude DOUBLE, innerLatitude DOUBLE)
  RETURNS DOUBLE
  BEGIN
	DECLARE  radLat1 double;
  DECLARE  radLat2 double;
  DECLARE  a double;
  DECLARE  b double;
  DECLARE  s double;
	if outerLongitude=0 THEN
		return 0;
	end if;
	SET  radLat1=outerLatitude * PI()/180;
	SET radLat2=innerLatitude * PI() / 180;
	SET a = radLat1 - radLat2 ;
	SET b = outerLongitude * PI() / 180 - innerLongitude * PI() / 180;
	SET s = 2 * asin(sqrt(pow(sin(a / 2), 2) + cos(radLat1)
                * cos(radLat2) * pow(sin(b / 2), 2))) ;

  SET s = s * 6378137.0;
  SET s = round(s * 10000) / 10000;
  return s;
END;
